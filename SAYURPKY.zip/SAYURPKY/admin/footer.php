</main>
<footer>
    <p>&copy; <?php echo date("Y"); ?> SAYURPKY Admin Panel</p>
</footer>
</body>
</html>
